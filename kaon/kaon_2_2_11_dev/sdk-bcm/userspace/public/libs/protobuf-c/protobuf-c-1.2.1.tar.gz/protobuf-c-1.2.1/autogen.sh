#!/bin/sh
exec autoreconf -fvi
